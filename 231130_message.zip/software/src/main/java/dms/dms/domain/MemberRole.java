package dms.dms.domain;

public enum MemberRole {
    USER, ADMIN;
}
