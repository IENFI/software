package dms.dms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DmzApplicationTests {

	@Test
	void contextLoads() {
	}

}
